package com.asinking.com.openapi.mapper.mp;

import com.asinking.com.openapi.entity.EbayShopListEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/** Mapper for eBay shop list operations. */
@Mapper
public interface EbayShopListMapper extends BaseMapper<EbayShopListEntity> {
}

