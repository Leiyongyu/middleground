package com.asinking.com.openapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 聚米汇中台系统启动类。
 */
@SpringBootApplication
@EnableScheduling
@EnableAsync
public class JmhMiddlePlatformSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(JmhMiddlePlatformSystemApplication.class, args);
    }
}
