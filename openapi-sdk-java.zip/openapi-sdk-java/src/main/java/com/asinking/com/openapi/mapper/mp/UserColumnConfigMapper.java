package com.asinking.com.openapi.mapper.mp;

import com.asinking.com.openapi.entity.UserColumnConfigEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserColumnConfigMapper extends BaseMapper<UserColumnConfigEntity> {
}
